# omnilives
crm project from josh omni

### to migrate the database edit `migrator.sh` and adjust to your database credentials. . and start the script `./migrator.sh`

### There is 1 speciall user that can do anything and have all priviledge for this application. . which is SuperAdmin, to create one you need to manually 
    insert it to database `user` and set  is_superAdmin to true
